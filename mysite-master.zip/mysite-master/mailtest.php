
<!DOCTYPE html>
<html>
<?php
$didMail = mail ('siddhantdanger@gmail.com', 'testsubject', 'sent with php',"From:");
echo $didMail;
?>
</html>

