
<?php

   header( 'Location: http://www.yoursite.com/new_page.html' ) ;

?>

